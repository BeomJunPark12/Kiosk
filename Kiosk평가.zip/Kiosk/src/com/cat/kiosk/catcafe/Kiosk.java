package com.cat.kiosk.catcafe;

import java.util.ArrayList;
import java.util.Scanner;

public class Kiosk {
	ProcMenuDrink procmenudrink = new ProcMenuDrink();
	ProcMenuDessert procmenudessert = new ProcMenuDessert();
	
	// Product만 받을 수 있는 basket ArrayList를 생성
	public static ArrayList<Product> basket = new ArrayList<>(); 

	public static Product p1 = new Product("아아", 2000);
	public static Product p2 = new Product("뜨아", 1500);
	public static Product p3 = new Product("오렌지 쥬스", 3000);
	public static Product p4 = new Product("마카롱", 5000);
	public static Product p5 = new Product("티라미수", 7000);

	public static Scanner sc = new Scanner(System.in);
	public static String cmd;

	void run() {

		Display.title();

		loop: while (true) {
			System.out.println("[1.음료 2.디저트 x.프로그램 종료]");
			System.out.println();
			cmd = sc.next();
			switch (cmd) {
			case "1":
				System.out.println("=================================");
				System.out.println("==============음료 리스트===========");
				System.out.println("=================================");
				p1.info();
				p2.info();
				p3.info();
				procmenudrink.run();
				break;
			case "2":
				System.out.println("=================================");
				System.out.println("============디저트 리스트===========");
				System.out.println("=================================");
				p4.info();
				p5.info();
				procmenudessert.run();
				break;
			case "x":
				// 상품 개수 처리
				int count = 0;
				count = count + basket.size();
				System.out.println("총 상품 개수: " + count + "개");
				
				// 총 금액
				int sum = 0;
				for (Product p : basket) {			// 향상된 for문 사용
					sum = sum + p.price;
				}
				System.out.println("총 금액: " + sum + "원");
				break loop;
			}
		}
		System.out.println("프로그램 종료");

	}
}
